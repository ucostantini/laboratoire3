package tp_notePartie1;

public class ClientNouveau implements StrategyFidelite {
    @Override
    public double getTaux() {
        return 1;
    }
}
