package tp_notePartie1;

import myImage.MyImage;

public interface Pizza {
    MyImage getPizzaIm();
    double cout();
    String getDescription();
}
