package tp_notePartie1;

public class ClientCarte implements StrategyFidelite {
    @Override
    public double getTaux() {
        return 0.9;
    }
}
