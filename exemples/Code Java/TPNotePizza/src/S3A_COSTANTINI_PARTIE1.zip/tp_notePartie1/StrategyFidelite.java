package tp_notePartie1;

public interface StrategyFidelite {
    double getTaux();
}
