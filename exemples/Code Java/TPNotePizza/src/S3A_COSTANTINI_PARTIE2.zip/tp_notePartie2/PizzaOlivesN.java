package tp_notePartie2;

public class PizzaOlivesN extends IngredientPizza {
    public PizzaOlivesN(Pizza pizza) {
        super(pizza, 0.25, "olives noires", "ing_olivesnoires.png");
    }
}
