package tp_notePartie2;

public class PizzaOignons extends IngredientPizza {
    public PizzaOignons(Pizza pizza) {
        super(pizza, 0.4, "oignons", "ing_oignons.png");
    }
}
