package tp_notePartie2;

public class PizzaOlivesV extends IngredientPizza {
    public PizzaOlivesV(Pizza pizza) {
        super(pizza, 0.3, "olives vertes", "ing_olivesvertes.png");
    }
}
