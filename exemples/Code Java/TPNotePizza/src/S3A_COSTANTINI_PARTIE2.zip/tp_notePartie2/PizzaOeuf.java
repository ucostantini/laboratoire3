package tp_notePartie2;

public class PizzaOeuf extends IngredientPizza {
    public PizzaOeuf(Pizza pizza) {
        super(pizza, 0.7, "oeuf", "ing_oeuf.png");
    }
}
