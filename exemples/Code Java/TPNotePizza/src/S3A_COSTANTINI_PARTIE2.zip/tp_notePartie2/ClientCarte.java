package tp_notePartie2;

public class ClientCarte implements StrategyFidelite {
    @Override
    public double getTaux() {
        return 0.9;
    }
}
