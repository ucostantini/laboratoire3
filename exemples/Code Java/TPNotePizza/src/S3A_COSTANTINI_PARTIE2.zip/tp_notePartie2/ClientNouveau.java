package tp_notePartie2;

public class ClientNouveau implements StrategyFidelite {
    @Override
    public double getTaux() {
        return 1;
    }
}
