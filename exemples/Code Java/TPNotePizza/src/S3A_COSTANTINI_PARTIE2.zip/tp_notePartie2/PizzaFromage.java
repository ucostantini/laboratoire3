package tp_notePartie2;

public class PizzaFromage extends IngredientPizza {
    public PizzaFromage(Pizza pizza) {
        super(pizza, 0.75, "fromage", "ing_fromage.png");
    }
}
