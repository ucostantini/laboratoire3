package tp_notePartie2;

public class PizzaChampignons extends IngredientPizza {
    public PizzaChampignons(Pizza pizza) {
        super(pizza, 0.5, "champignons", "ing_champignons.png");
    }
}
