package tp_notePartie2;

import myImage.MyImage;

public interface Pizza {
    MyImage getPizzaIm();
    double cout();
    String getDescription();
}
