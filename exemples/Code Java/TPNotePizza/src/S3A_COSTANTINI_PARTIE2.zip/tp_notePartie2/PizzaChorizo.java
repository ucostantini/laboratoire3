package tp_notePartie2;

public class PizzaChorizo extends IngredientPizza {
    public PizzaChorizo(Pizza pizza) {
        super(pizza, 1, "chorizos", "ing_chorizo.png");
    }
}
