package tp_notePartie2;

public interface StrategyFidelite {
    double getTaux();
}
